import { Bot } from 'lucide-react';

function BotCard() {
  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl p-6 shadow-2xl w-72 flex-shrink-0">
      <div className="bg-gradient-to-br from-blue-400 to-blue-500 rounded-2xl p-8 mb-4 shadow-lg">
        <div className="bg-blue-600 rounded-t-3xl px-6 py-4 mb-6 relative">
          <div className="flex gap-2 mb-2">
            <div className="w-3 h-3 bg-teal-300 rounded-full"></div>
            <div className="w-3 h-3 bg-teal-300 rounded-full"></div>
          </div>
        </div>
        <div className="flex justify-center gap-4">
          <div className="bg-yellow-600 rounded-xl w-16 h-12 shadow-md"></div>
          <div className="bg-yellow-600 rounded-xl w-16 h-12 shadow-md"></div>
        </div>
      </div>
      <h2 className="text-2xl font-bold text-center" style={{ fontFamily: 'Comic Sans MS, cursive' }}>
        Bluebot concept
      </h2>
    </div>
  );
}

export default BotCard;
