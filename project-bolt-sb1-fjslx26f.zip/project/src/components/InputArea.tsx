import { Send } from 'lucide-react';

interface InputAreaProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
}

function InputArea({ value, onChange, onSend }: InputAreaProps) {
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSend();
    }
  };

  return (
    <div className="bg-gradient-to-r from-teal-200 to-teal-100 rounded-3xl shadow-2xl p-6">
      <div className="flex items-center gap-4">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask anything . . ."
          className="flex-1 bg-white/80 backdrop-blur-sm rounded-2xl px-6 py-4 text-lg text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-teal-400 shadow-inner"
          style={{ fontFamily: 'Comic Sans MS, cursive' }}
        />
        <button
          onClick={onSend}
          className="bg-gradient-to-r from-orange-400 to-orange-500 hover:from-orange-500 hover:to-orange-600 rounded-2xl p-4 shadow-lg transition-all duration-200 hover:scale-110 focus:outline-none focus:ring-4 focus:ring-orange-300"
        >
          <Send className="w-6 h-6 text-white" />
        </button>
      </div>
    </div>
  );
}

export default InputArea;
