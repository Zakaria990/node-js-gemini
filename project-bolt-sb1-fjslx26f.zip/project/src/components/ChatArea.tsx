import { Bot, User } from 'lucide-react';

interface Message {
  text: string;
  isUser: boolean;
}

interface ChatAreaProps {
  messages: Message[];
}

function ChatArea({ messages }: ChatAreaProps) {
  return (
    <div className="flex-1 bg-gradient-to-br from-blue-400 to-blue-500 rounded-3xl shadow-2xl p-8 overflow-y-auto">
      {messages.length === 0 ? (
        <div className="h-full flex items-center justify-center">
          <div className="text-center">
            <Bot className="w-24 h-24 text-blue-300 mx-auto mb-4 opacity-50" />
            <p className="text-blue-200 text-xl font-medium">Start a conversation with Furiza AI</p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex items-start gap-3 ${message.isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div className={`p-2 rounded-full ${message.isUser ? 'bg-teal-400' : 'bg-blue-600'} shadow-lg`}>
                {message.isUser ? (
                  <User className="w-6 h-6 text-white" />
                ) : (
                  <Bot className="w-6 h-6 text-white" />
                )}
              </div>
              <div
                className={`px-6 py-3 rounded-2xl max-w-md shadow-lg ${
                  message.isUser
                    ? 'bg-teal-400 text-gray-800'
                    : 'bg-white text-gray-800'
                }`}
              >
                <p className="text-base">{message.text}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ChatArea;
