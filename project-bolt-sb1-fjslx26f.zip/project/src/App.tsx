import { X } from 'lucide-react';
import { useState } from 'react';
import BotCard from './components/BotCard';
import ChatArea from './components/ChatArea';
import InputArea from './components/InputArea';

function App() {
  const [messages, setMessages] = useState<Array<{ text: string; isUser: boolean }>>([]);
  const [inputValue, setInputValue] = useState('');

  const handleSendMessage = () => {
    if (inputValue.trim()) {
      setMessages([...messages, { text: inputValue, isUser: true }]);
      setInputValue('');

      setTimeout(() => {
        setMessages(prev => [...prev, {
          text: "Hello! I'm Furiza AI. How can I assist you today?",
          isUser: false
        }]);
      }, 1000);
    }
  };

  const handleClose = () => {
    if (confirm('Are you sure you want to close?')) {
      window.close();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-400 via-teal-500 to-emerald-400 p-8">
      <div className="max-w-7xl mx-auto h-[calc(100vh-4rem)] flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <div className="bg-gradient-to-r from-teal-300 to-teal-200 rounded-3xl px-8 py-4 shadow-lg">
            <h1 className="text-3xl font-bold text-orange-500" style={{ fontFamily: 'Comic Sans MS, cursive' }}>
              Welcome To Furiza AI
            </h1>
          </div>
          <button
            onClick={handleClose}
            className="bg-red-400 hover:bg-red-500 rounded-2xl p-4 shadow-lg transition-all duration-200 hover:scale-110"
          >
            <X className="w-8 h-8 text-white" strokeWidth={3} />
          </button>
        </div>

        <div className="flex-1 flex gap-6 mb-6 overflow-hidden">
          <BotCard />
          <ChatArea messages={messages} />
        </div>

        <InputArea
          value={inputValue}
          onChange={setInputValue}
          onSend={handleSendMessage}
        />
      </div>
    </div>
  );
}

export default App;
